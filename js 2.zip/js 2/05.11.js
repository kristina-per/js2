let number = 11;
if (number > 50) {
    console.log ("more")
} 
else {
    console.log( "Less" )
}

let number2 = 18 ;
if (number2 == 0) {
    console.log ("0")
} 
else (number < 0)
{
    console.log( "-" )
}
 
let number3 = 7; 
squared = number3 ** number3
if (squared > 100 )
     console.log (">100")
else {
    console.log ("<100")
}